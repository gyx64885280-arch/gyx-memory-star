# 宜居星图分析服务
在解压目录运行 `node backend/server.mjs`，需要 Node.js 22 或更新版本。默认服务为 http://127.0.0.1:8785，可通过 PORT、HOST 和 ALLOWED_ORIGINS 配置。生产环境应在单位自己的 HTTPS 网关后运行，并由网关负责鉴权和访问配额。
 
POST /v1/analyze 接收 JSON，例如 {"area":0,"role":"govern","cat":"医疗","senior":false}。area 的 0、1、2 对应回龙观、望京、广安门内。role 可取 resident、merchant、govern。mode 可取 walk、bike、bus。返回路网、楼栋、设施到达时间、候选点排名及两种治理情景的评估。
 
配置门户 site/config.mjs 的 serviceBase 为 HTTPS 服务地址，并在服务端允许门户域名。接口与公开版使用同一示例计算引擎。真实数据接入时须核验路网连通、节点位置、容量与人口口径。该服务不接收试用申请或联系人信息。
