// Start with: node backend/server.mjs. Put an HTTPS reverse proxy in front for deployment.
import http from 'node:http';
import {runAnalysis} from '../site/engine.mjs';
const allowed=new Set((process.env.ALLOWED_ORIGINS||'http://localhost:8775,https://gyx64885280-arch.github.io').split(','));
const server=http.createServer(async(req,res)=>{
 const origin=req.headers.origin;
 if(origin&&!allowed.has(origin)){res.writeHead(403);res.end();return;}
 res.setHeader('Vary','Origin');if(origin)res.setHeader('Access-Control-Allow-Origin',origin);
 res.setHeader('Content-Type','application/json; charset=utf-8');
 res.setHeader('Access-Control-Allow-Methods','POST, OPTIONS');
 res.setHeader('Access-Control-Allow-Headers','Content-Type');
 if(req.url!=='/v1/analyze'){res.writeHead(404);res.end('{}');return;}
 if(req.method==='OPTIONS'){res.writeHead(204);res.end();return;}
 if(req.method!=='POST'){res.writeHead(405);res.end('{}');return;}
 try{
   let length=0;const chunks=[];
   for await(const chunk of req){length+=chunk.length;if(length>8192){res.writeHead(413);res.end('{}');return;}chunks.push(chunk);}
   const input=JSON.parse(Buffer.concat(chunks).toString());const result=runAnalysis(input);
   res.end(JSON.stringify(result));
 }catch{res.writeHead(400);res.end(JSON.stringify({error:'无效的分析请求'}));}
});
server.listen(Number(process.env.PORT||8785),process.env.HOST||'127.0.0.1',()=>console.log('宜居星图分析服务已启动'));
